//
//  ViewController.swift
//  Stars
//
//  Created by Balasubramanian on 15/03/19.
//  Copyright © 2019 Balasubramanian. All rights reserved.
//


//https://www.paintcodeapp.com/tutorials
import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
       
        
        let customView1 = ButtonView(frame: CGRect(x: 10, y: 260, width: 50, height: 30))
        customView1.backgroundColor = UIColor.clear
        self.view.addSubview(customView1)
        
        let customView2 = ButtonView(frame: CGRect(x: 60, y: 260, width: 50, height: 30))
        customView2.backgroundColor = UIColor.clear
        self.view.addSubview(customView2)
        
        let customView3 = ButtonView(frame: CGRect(x: 110, y: 260, width: 50, height: 30))
        customView3.backgroundColor = UIColor.clear
        self.view.addSubview(customView3)
        
        
     
       
       
    }
    
  


    
    
   


}

