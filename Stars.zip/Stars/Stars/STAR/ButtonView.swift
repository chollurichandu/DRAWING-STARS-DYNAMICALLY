//
//  ButtonView.swift
//  DynamicShapesBasics
//
//  Created by AuthorName on 10/10/2018.
//  Copyright © 2018 CompanyName. All rights reserved.
//

import UIKit

class ButtonView: UIView {

    override func draw(_ rect: CGRect) {
        // Drawing code
        MyStyleKit.drawRateButton(frame: self.bounds)
    }


}
